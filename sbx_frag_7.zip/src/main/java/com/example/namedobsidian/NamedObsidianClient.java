package com.example.namedobsidian;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;

public class NamedObsidianClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // 黑曜石：命名 "Void.exp" 触发 void 模型
        ItemProperties.register(
            Items.OBSIDIAN,
            ResourceLocation.withDefaultNamespace("void"),
            (stack, world, entity, seed) -> {
                if (stack.hasCustomName()) {
                    String name = stack.getCustomName().getString();
                    if (name.equals("Void.exp")) return 1.0f;
                }
                return 0.0f;
            }
        );

        // 哭泣黑曜石：命名 "<SKY.GEM>" 触发 sky 模型
        ItemProperties.register(
            Items.CRYING_OBSIDIAN,
            ResourceLocation.withDefaultNamespace("sky"),
            (stack, world, entity, seed) -> {
                if (stack.hasCustomName()) {
                    String name = stack.getCustomName().getString();
                    if (name.equals("<SKY.GEM>")) return 1.0f;
                }
                return 0.0f;
            }
        );
    }
}