package com.example.namedobsidian;

import net.fabricmc.api.ModInitializer;

public class NamedObsidianMod implements ModInitializer {
    @Override
    public void onInitialize() {
        // 不需要写东西
    }
}