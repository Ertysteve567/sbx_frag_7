package com.example.namedobsidian;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

import java.util.concurrent.ConcurrentHashMap;

public class ObsidianData {
    private static final ConcurrentHashMap<BlockPos, String> CLIENT_MAP = new ConcurrentHashMap<>();

    public static void putName(BlockPos pos, String name) {
        CLIENT_MAP.put(pos, name);
    }

    public static String getClientName(Level world, BlockPos pos) {
        return CLIENT_MAP.get(pos);
    }

    public static void remove(BlockPos pos) {
        CLIENT_MAP.remove(pos);
    }
}