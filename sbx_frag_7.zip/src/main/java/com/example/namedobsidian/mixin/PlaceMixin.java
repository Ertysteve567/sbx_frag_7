package com.example.namedobsidian.mixin;

import com.example.namedobsidian.ObsidianData;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockItem.class)
public class PlaceMixin {
    @Inject(method = "place", at = @At("RETURN"))
    private void onPlace(BlockPlaceContext context, CallbackInfoReturnable<InteractionResult> cir) {
        if (cir.getReturnValue().consumesAction() && context.getItemInHand().hasCustomName()) {
            Level world = context.getLevel();
            if (world.isClientSide()) {
                BlockPos pos = context.getClickedPos();
                String name = context.getItemInHand().getCustomName().getString();
                ObsidianData.putName(pos, name);
            }
        }
    }
}