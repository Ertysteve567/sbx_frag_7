package com.example.namedobsidian.mixin;

import com.example.namedobsidian.ObsidianData;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(BlockRenderDispatcher.class)
public class BlockRenderDispatcherMixin {
    @ModifyVariable(
        method = "renderBlock",
        at = @At("HEAD"),
        argsOnly = true,
        index = 3
    )
    private BakedModel replaceModel(BakedModel original,
                                    BlockState state,
                                    BlockPos pos,
                                    BlockAndTintGetter world,
                                    PoseStack poseStack,
                                    MultiBufferSource buffer,
                                    boolean cull,
                                    RandomSource random,
                                    long seed,
                                    int overlay) {
        if (world.isClientSide()) {
            String name = ObsidianData.getClientName(world, pos);
            if (name != null) {
                Minecraft client = Minecraft.getInstance();
                if (state.getBlock() == Blocks.OBSIDIAN && name.equals("Void.exp")) {
                    BakedModel custom = client.getModelManager().getModel(ResourceLocation.withDefaultNamespace("block/obsidian_void"));
                    if (custom != null) return custom;
                } else if (state.getBlock() == Blocks.CRYING_OBSIDIAN && name.equals("<SKY.GEM>")) {
                    BakedModel custom = client.getModelManager().getModel(ResourceLocation.withDefaultNamespace("block/crying_obsidian_sky"));
                    if (custom != null) return custom;
                }
            }
        }
        return original;
    }
}