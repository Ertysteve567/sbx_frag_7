package com.example.namedobsidian.mixin;

import com.example.namedobsidian.ObsidianData;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Block.class)
public class BlockRemoveMixin {
    @Inject(method = "onRemove", at = @At("HEAD"))
    private void onRemove(BlockState state, Level world, BlockPos pos, BlockState newState, boolean moved, CallbackInfo ci) {
        if (world.isClientSide()) {
            ObsidianData.remove(pos);
        }
    }
}